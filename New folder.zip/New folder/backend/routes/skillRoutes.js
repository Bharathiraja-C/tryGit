const express = require('express');
const router = express.Router();
const CertificationController = require('../controllers/CertificationController');

router.get('/project-details/:userId', CertificationController.getProjectDetails);
router.get('/skill-details/:userId', CertificationController.getSkillDetails);

module.exports = router;