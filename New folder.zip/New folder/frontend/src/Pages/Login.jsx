import React, { useState } from "react";
import { Button, Alert, Form, Modal, Col } from "react-bootstrap";
import "./Login.css";
import AuthService from "../Services/AuthService";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false); // Loading state
  const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false); // State for showing/hiding the forgot password modal
  const [forgotPasswordEmail, setForgotPasswordEmail] = useState(""); 
  const navigate = useNavigate();
  const handleForgotPassword = async () => {
    try {
      // Call the backend API to initiate the "Forgot Password" process
      await AuthService.forgotPassword(forgotPasswordEmail);
      // Show success message to the user
      alert("Instructions to reset your password have been sent to your email address.");
      // Close the forgot password modal
      setShowForgotPasswordModal(false);
    } catch (error) {
      console.error("Forgot Password failed:", error);
      setError("Failed to initiate the forgot password process. Please try again.");
    }
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); // Set loading state to true
    try {
      const result = await AuthService.login(email, password);
      const { username, role } = result.user;
      localStorage.setItem("token", result.token);
      localStorage.setItem("role", result.user.role);
      localStorage.setItem("username", result.user.username);
      localStorage.setItem("userid", result.user.id);
      const nextPage =
        result.user.role === "admin"
          ? "/create-user"
          : `/add-certifications/${result.user.id}`;
      // Redirect only when token is successfully stored
      navigate(nextPage, { state: { username, token: result.token, role } });
    } catch (error) {
      console.error("Login failed:", error);
      setError("Invalid email or password");
    } finally {
      setLoading(false); // Reset loading state
    }
  };

  return (
    <div className="form-head">
      <center className="login-head">Login</center>
      <br />
      {error && <Alert variant="danger">{error}</Alert>}
      <Form onSubmit={handleSubmit}>
        <Form.Group controlId="formBasicEmail">
          <Form.Label>Email Id</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Form.Group>
        <Button className="Button" type="submit" disabled={loading} block>
          {loading ? "Logging in..." : "Log In"}{" "}
          {/* Display loading text when logging in */}
        </Button>
        <Button variant="link" onClick={() => setShowForgotPasswordModal(true)} block>
          Forgot Password?
        </Button>
      </Form>
      <Modal show={showForgotPasswordModal} onHide={() => setShowForgotPasswordModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Forgot Password</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form.Group controlId="formBasicEmail">
            <Form.Label>Email Address</Form.Label>
            <Form.Control
              type="email"
              placeholder="Enter email"
              value={forgotPasswordEmail}
              onChange={(e) => setForgotPasswordEmail(e.target.value)}
            />
          </Form.Group>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowForgotPasswordModal(false)}>
            Close
          </Button>
          <Button variant="primary" onClick={handleForgotPassword}>
            Submit
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Login;
