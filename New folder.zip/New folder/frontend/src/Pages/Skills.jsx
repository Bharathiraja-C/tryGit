import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Button } from "react-bootstrap";
import "./userDetails.css";

const UserDetails = ({ userId }) => {
  const [userDetails, setUserDetails] = useState({});

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const userData = await SkillService.getSkillDetails(userId);
        setUserDetails(userData);
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [userId]);
  return (
    <div className="div1">
      <h2 className="userD">Skill Details</h2>
      {userDetails && (
        <div>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">Skill Name</th>
                  <th className="table-header">Proficiency Level</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.map((skill, index) => (
                  <React.Fragment key={index}>
                      <tr>
                        <td>{skill.skillname}</td>
                        <td>{skill.proficiencylevel}</td>
                      </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No skills found</p>
          )}

        </div>
      )}
    </div>
  );
};

export default UserDetails;
