
import React from 'react';
import { MegaMenu } from 'primereact/megamenu';
import { InputText } from 'primereact/inputtext';
import { Ripple } from 'primereact/ripple';
import {Avatar } from 'primereact/avatar';
import { Button } from 'primereact/button';

export default function TemplateDemo() {
    return (
        <div className="card">
            <MegaMenu  orientation="horizontal" start={start} end={end} breakpoint="960px" className="p-3 surface-0 shadow-2" style={{ borderRadius: '3rem' }} />
        </div>
    )
}
        