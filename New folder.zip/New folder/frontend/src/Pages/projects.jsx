import React, { useState, useEffect } from "react";
import SkillService from "../Services/SkillServices";
import { Table, Button } from "react-bootstrap";
import { useLocation } from 'react-router-dom';
import "./userDetails.css";

const Projects = ({ userId }) => {
  const [userDetails, setUserDetails] = useState({});
  const location = useLocation();
  const project = location.state && location.state.project;
  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        const userData = await SkillService.getProjectDetails(userId);
        setUserDetails(userData);
      } catch (error) {
        console.error("Error fetching user details:", error);
      }
    };

    fetchUserDetails();
  }, [userId]);
useEffect(()=>{
    console.log("page",project);
    console.log("userDetails",userDetails);
},[userDetails]);

  return (
    <div className="div1">
      <h2 className="userD">Project Details</h2>
      {userDetails && (
        <div>
          {userDetails && userDetails.length > 0 ? (
            <Table striped bordered hover>
              <thead>
                <tr>
                  <th className="table-header">Project Name</th>
                  <th className="table-header">Project Description</th>
                  <th className="table-header">Project Experience</th>
                  <th className="table-header">Status</th>
                </tr>
              </thead>
              <tbody>
                {userDetails.map((project, index) => (
                  <React.Fragment key={index}>
                      <tr>
                        <td>{project.projectname}</td>
                        <td>{project.projectdescription}</td>
                        <td>{project.projectexperience}</td>
                        <td>{project.status}</td>
                      </tr>
                  </React.Fragment>
                ))}
              </tbody>
            </Table>
          ) : (
            <p>No projects found</p>
          )}
    </div>
  )
}
</div>
  )

}
export default Projects;
