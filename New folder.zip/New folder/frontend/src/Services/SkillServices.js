import axios from 'axios';

const SkillService ={
    async getProjectDetails(userId)  {
        try {
          // Make a fetch request to your backend API to fetch user details
          const response = await fetch(`http://localhost:5000/api/project-details/${userId}`); // Replace '/api/users/${userId}' with your actual API endpoint
          if (!response.ok) {
            throw new Error('Failed to fetch user details');
          }
          console.log(response);
          const userData = await response.json();
          return userData;
        } catch (error) {
          console.error('Error fetching user details:', error);
          throw error;
        }
      },
      async getSkillDetails(userId)  {
        try {
          // Make a fetch request to your backend API to fetch user details
          const response = await fetch(`http://localhost:5000/api/skill-details/${userId}`); // Replace '/api/users/${userId}' with your actual API endpoint
          if (!response.ok) {
            throw new Error('Failed to fetch user details');
          }
          console.log(response);
          const userData = await response.json();
          return userData;
        } catch (error) {
          console.error('Error fetching user details:', error);
          throw error;
        }
      }
};
export default SkillService;