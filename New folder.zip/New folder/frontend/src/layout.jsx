import React from "react";
import { Outlet } from "react-router-dom";
import Header from "./components/Menu";
import Sidebar from "./components/Sidebar";

const Layout = () => {
  return (
    <>
      <Header />
      {/* <div className="sidebar-wrapper">
        <Sidebar />
      </div>
      <div className="content-wrapper">
        <Outlet />
      </div> */}
      <Outlet/>
    </>
  );
};

export default Layout;
